#include "src\Engine\AEX.h"
#include "MouseCamController.h"
using namespace AEX;

AEX_RTTI_IMPL(MouseCamController, AEX::LogicComp);
MouseCamController::MouseCamController()
	: mpCam(NULL)
	, mpTr(NULL)
{}

void MouseCamController::Initialize()
{
	LogicComp::Initialize();
	mpCam = GetOwner()->GetComp<Camera>();
	mpTr = GetOwner()->GetComp<TransformComp3D>();
}

// state behaviors
void MouseCamController::Update()
{
	f32 moveSpeed = 1.0f;
	f32 zoomSpeed = -0.10f;
	f32 zoomFactor = mpCam->GetViewRect().x / mpCam->GetViewport().GetRect().x;
	// position 
	if (mpTr && aexInput->MousePressed(AEX::Input::eMouseMiddle))
	{
		auto pos = mpTr->GetPosition();
		auto mov = AEVec3(aexInput->GetMouseMovement().x, aexInput->GetMouseMovement().y, 0.0f);
		pos += mov * moveSpeed * zoomFactor;
		mpTr->SetPosition(pos);
	}

	auto cvr = mpCam->GetViewRect();
	auto mw = aexInput->GetMouseWheel();
	cvr *= (1 + mw*zoomSpeed);
	mpCam->SetViewRect(cvr);
}