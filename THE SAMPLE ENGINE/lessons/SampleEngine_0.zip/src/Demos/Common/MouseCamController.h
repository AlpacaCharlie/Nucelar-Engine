#pragma once

// Demo comps
class MouseCamController : public AEX::LogicComp
{
	AEX_RTTI_DECL;
public:
	AEX::Camera * mpCam;
	AEX::TransformComp3D * mpTr;
public:
	MouseCamController();
	virtual void Initialize();
	virtual void Update();
};