#ifndef AEX_GL_INCLUDES_H_
#define AEX_GL_INCLUDES_H_

// OpenGL libraries
#include <Extern\GL\glew.h>
#include <Extern\GL\wglew.h>
#include <Extern\GL\GL.h>
#include "..\Debug\CheckGLError.h"

#endif